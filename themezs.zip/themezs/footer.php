

<!-- footer part stert -->
<footer class="cont"></footer>
<!-- footer part end -->
</body>
</html>